"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
var serverless = require("serverless-http");
var express = require("express");
var app = express();
var get_1 = require("./get");
var post_1 = require("./post");
app.get("/", get_1.get);
app.post("/", post_1.post);
exports.handler = serverless(app);
//# sourceMappingURL=handler.js.map