"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.connection = exports.CLUSTER_ENDPOINT = void 0;
var web3_js_1 = require("@solana/web3.js");
exports.CLUSTER_ENDPOINT = process.env.CLUSTER_ENDPOINT || 'https://api.devnet.solana.com';
exports.connection = new web3_js_1.Connection(exports.CLUSTER_ENDPOINT || 'https://api.devnet.solana.com', 'confirmed');
//# sourceMappingURL=index.js.map